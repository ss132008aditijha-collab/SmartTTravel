from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
import random

app = Flask(__name__)
app.secret_key = "smarttravel-secret-key"
DATABASE = "smarttravel.db"


def get_db_connection():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection


@app.route("/")
def home():
    return render_template("home.html")

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get("email")
        password = request.form.get("password")

        connection = get_db_connection()

        user = connection.execute(
            "SELECT * FROM users WHERE email = ? AND password = ?",
            (email, password)
        ).fetchone()

        connection.close()

        if user is None:
            return """
                <script>
                    alert("Invalid email or password.");
                    window.location.href = "/login";
                </script>
            """

        session["user_id"] = user["id"]
        session["user_name"] = user["name"]
        session["user_email"] = user["email"]

        return redirect(url_for("home"))

    return render_template("login.html")

@app.route("/logout")
def logout():

    session.clear()

    return redirect(url_for("home"))

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form.get("name")
        email = request.form.get("email")
        phone = request.form.get("phone")
        password = request.form.get("password")

        connection = get_db_connection()

        try:
            connection.execute(
                """
                INSERT INTO users (name, email, phone, password)
                VALUES (?, ?, ?, ?)
                """,
                (name, email, phone, password)
            )

            connection.commit()

        except sqlite3.IntegrityError:
            connection.close()

            return """
                <script>
                    alert("An account with this email already exists.");
                    window.location.href = "/register";
                </script>
            """

        connection.close()

        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():

    if request.method == "POST":

        email = request.form.get("email")

        connection = get_db_connection()

        user = connection.execute(
            "SELECT * FROM users WHERE email = ?",
            (email,)
        ).fetchone()

        connection.close()

        if user is None:
            return """
                <script>
                    alert("No account found with this email address.");
                    window.location.href = "/forgot-password";
                </script>
            """

        return redirect(
            url_for("reset_password", email=email)
        )

    return render_template("forgot_password.html")

@app.route("/reset-password", methods=["GET", "POST"])
def reset_password():

    email = request.args.get("email")

    if request.method == "POST":

        new_password = request.form.get("password")

        connection = get_db_connection()

        connection.execute(
            """
            UPDATE users
            SET password = ?
            WHERE email = ?
            """,
            (new_password, email)
        )

        connection.commit()
        connection.close()

        return redirect(url_for("login"))

    return render_template(
        "reset_password.html",
        email=email
    )

@app.route("/search")
def search():

    source = request.args.get("source")
    destination = request.args.get("destination")
    journey_date = request.args.get("journey_date")
    transport = request.args.get("transport", "train")

    trains = [
        {
            "name": "Karnataka Express",
            "number": "12627",
            "departure": "19:20",
            "arrival": "06:00",
            "duration": "10h 40m",
            "price": 650,
            "seats": 24
        },
        {
            "name": "Chennai Express",
            "number": "12608",
            "departure": "22:30",
            "arrival": "07:00",
            "duration": "8h 30m",
            "price": 720,
            "seats": 18
        }
    ]

    buses = [
        {
            "name": "Airavat Express",
            "number": "KA-01-AB-1234",
            "departure": "21:30",
            "arrival": "06:30",
            "duration": "9h",
            "price": 850,
            "seats": 12
        },
        {
            "name": "Rajahamsa",
            "number": "KA-05-CD-5678",
            "departure": "20:00",
            "arrival": "05:30",
            "duration": "9h 30m",
            "price": 700,
            "seats": 20
        }
    ]

    if transport == "bus":
        results = buses
    else:
        results = trains
# Temporary test for the No Results page
    if source and source.strip().lower() == "testcity":
        results = []

        return render_template(
            "search_results.html",
            results=results,
            source=source,
            destination=destination,
            journey_date=journey_date,
            transport=transport
        )


@app.route("/booking")
def booking():

    name = request.args.get("name")
    number = request.args.get("number")
    price = request.args.get("price")
    transport = request.args.get("transport")
    source = request.args.get("source")
    destination = request.args.get("destination")
    journey_date = request.args.get("date")

    return render_template(
        "booking.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date
    )


@app.route("/seat-selection")
def seat_selection():

    name = request.args.get("name")
    number = request.args.get("number")
    price = request.args.get("price")
    transport = request.args.get("transport")
    source = request.args.get("source")
    destination = request.args.get("destination")
    journey_date = request.args.get("date")
    boarding = request.args.get("boarding")

    return render_template(
        "seat_selection.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        boarding=boarding
    )


@app.route("/passenger-details")
def passenger_details():

    name = request.args.get("name")
    number = request.args.get("number")
    price = request.args.get("price")
    transport = request.args.get("transport")
    source = request.args.get("source")
    destination = request.args.get("destination")
    journey_date = request.args.get("date")
    boarding = request.args.get("boarding")
    seat = request.args.get("seat")

    return render_template(
        "passenger_details.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        boarding=boarding,
        seat=seat
    )


@app.route("/food")
def food():

    name = request.args.get("name")
    number = request.args.get("number")
    price = request.args.get("price")
    transport = request.args.get("transport")
    source = request.args.get("source")
    destination = request.args.get("destination")
    journey_date = request.args.get("date")
    boarding = request.args.get("boarding")
    seat = request.args.get("seat")

    passenger_name = request.args.get("passenger_name")
    age = request.args.get("age")
    gender = request.args.get("gender")
    phone = request.args.get("phone")
    email = request.args.get("email")

    return render_template(
        "food.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        boarding=boarding,
        seat=seat,
        passenger_name=passenger_name,
        age=age,
        gender=gender,
        phone=phone,
        email=email
    )


@app.route("/payment")
def payment():

    name = request.args.get("name")
    number = request.args.get("number")
    price = request.args.get("price")
    transport = request.args.get("transport")
    source = request.args.get("source")
    destination = request.args.get("destination")
    journey_date = request.args.get("date")
    boarding = request.args.get("boarding")
    seat = request.args.get("seat")

    passenger_name = request.args.get("passenger_name")
    age = request.args.get("age")
    gender = request.args.get("gender")
    phone = request.args.get("phone")
    email = request.args.get("email")

    food_total = request.args.get("food_total", "0")

    total = float(price) + float(food_total)

    return render_template(
        "payment.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        boarding=boarding,
        seat=seat,
        passenger_name=passenger_name,
        age=age,
        gender=gender,
        phone=phone,
        email=email,
        food_total=food_total,
        total=total
    )



@app.route("/ticket")
def ticket():
    booking_id = request.args.get("booking_id")

    # If a booking ID is provided, retrieve the saved booking
    if booking_id:
        connection = sqlite3.connect("smarttravel.db")
        connection.row_factory = sqlite3.Row

        booking = connection.execute(
            "SELECT * FROM bookings WHERE booking_id = ?",
            (booking_id,)
        ).fetchone()

        connection.close()

        if booking is None:
            return "Booking not found. Please check the booking ID.", 404

        # Map database column names to ticket template variables
        return render_template(
            "ticket.html",
            name=booking["vehicle_name"],
            number=booking["vehicle_number"],
            price=booking["ticket_price"],
            transport=booking["transport"],
            source=booking["source"],
            destination=booking["destination"],
            journey_date=booking["journey_date"],
            boarding=booking["boarding"],
            seat=booking["seat"],
            passenger_name=booking["passenger_name"],
            age=booking["age"],
            gender=booking["gender"],
            phone=booking["phone"],
            email=booking["email"],
            food_total=booking["food_total"] or 0,
            total=booking["total"],
            payment_method=booking["payment_method"],
            booking_id=booking["booking_id"]
        )

    # Keep support for the original ticket URL
    name = request.args.get("name")
    number = request.args.get("number")
    price = request.args.get("price")
    transport = request.args.get("transport")
    source = request.args.get("source")
    destination = request.args.get("destination")
    journey_date = request.args.get("date")
    boarding = request.args.get("boarding")
    seat = request.args.get("seat")
    passenger_name = request.args.get("passenger_name")
    age = request.args.get("age")
    gender = request.args.get("gender")
    phone = request.args.get("phone")
    email = request.args.get("email")
    food_total = request.args.get("food_total", "0")
    total = request.args.get("total", price)
    payment_method = request.args.get("payment_method")

    return render_template(
        "ticket.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        boarding=boarding,
        seat=seat,
        passenger_name=passenger_name,
        age=age,
        gender=gender,
        phone=phone,
        email=email,
        food_total=food_total,
        total=total,
        payment_method=payment_method,
        booking_id=booking_id
    )


# ==========================================================
# MY BOOKINGS
# ==========================================================

@app.route("/bookings")
def bookings():

    if "user_id" not in session:
        return redirect(url_for("login"))

    connection = get_db_connection()

    bookings = connection.execute(
        """
        SELECT * FROM bookings
        WHERE email = ?
        ORDER BY id DESC
        """,
        (session["user_email"],)
    ).fetchall()

    connection.close()

    return render_template(
        "bookings.html",
        bookings=bookings
    )


# ==========================================================
# COMPLETE BOOKING
# ==========================================================

@app.route("/complete-booking", methods=["POST"])
def complete_booking():

    name = request.form.get("name")
    number = request.form.get("number")
    price = request.form.get("price")
    transport = request.form.get("transport")
    source = request.form.get("source")
    destination = request.form.get("destination")
    journey_date = request.form.get("date")
    boarding = request.form.get("boarding")
    seat = request.form.get("seat")

    passenger_name = request.form.get("passenger_name")
    age = request.form.get("age")
    gender = request.form.get("gender")
    phone = request.form.get("phone")
    email = request.form.get("email")

    food_total = request.form.get("food_total", "0")
    total = request.form.get("total", price)
    payment_method = request.form.get("payment_method")

    # Generate a unique booking ID
    booking_id = "ST" + str(random.randint(100000, 999999))

    connection = get_db_connection()

    connection.execute(
        """
        INSERT INTO bookings (
            booking_id,
            transport,
            vehicle_name,
            vehicle_number,
            source,
            destination,
            journey_date,
            boarding,
            seat,
            passenger_name,
            age,
            gender,
            phone,
            email,
            ticket_price,
            food_total,
            total,
            payment_method,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            booking_id,
            transport,
            name,
            number,
            source,
            destination,
            journey_date,
            boarding,
            seat,
            passenger_name,
            age,
            gender,
            phone,
            email,
            float(price),
            float(food_total),
            float(total),
            payment_method,
            "CONFIRMED"
        )
    )

    connection.commit()
    connection.close()

    return redirect(
        url_for(
            "ticket",
            name=name,
            number=number,
            price=price,
            transport=transport,
            source=source,
            destination=destination,
            date=journey_date,
            boarding=boarding,
            seat=seat,
            passenger_name=passenger_name,
            age=age,
            gender=gender,
            phone=phone,
            email=email,
            food_total=food_total,
            total=total,
            payment_method=payment_method,
            booking_id=booking_id
        )
    )


if __name__ == "__main__":
    app.run(debug=True)