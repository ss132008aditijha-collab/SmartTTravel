import sqlite3

DATABASE = "smarttravel.db"


def get_db_connection():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection


def create_database():

    connection = get_db_connection()

    cursor = connection.cursor()

    # =========================
    # USERS TABLE
    # =========================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            name TEXT NOT NULL,

            email TEXT UNIQUE NOT NULL,

            phone TEXT NOT NULL,

            password TEXT NOT NULL

        )
    """)

    # =========================
    # BOOKINGS TABLE
    # =========================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS bookings (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            booking_id TEXT UNIQUE,

            transport TEXT,

            vehicle_name TEXT,

            vehicle_number TEXT,

            source TEXT,

            destination TEXT,

            journey_date TEXT,

            boarding TEXT,

            seat TEXT,

            passenger_name TEXT,

            age INTEGER,

            gender TEXT,

            phone TEXT,

            email TEXT,

            ticket_price REAL,

            food_total REAL,

            total REAL,

            payment_method TEXT,

            status TEXT DEFAULT 'CONFIRMED'

        )
    """)

    # =========================
    # VEHICLES TABLE
    # =========================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS vehicles (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            transport TEXT NOT NULL,

            name TEXT NOT NULL,

            number TEXT UNIQUE NOT NULL,

            source TEXT NOT NULL,

            destination TEXT NOT NULL,

            departure TEXT NOT NULL,

            arrival TEXT NOT NULL,

            duration TEXT NOT NULL,

            price REAL NOT NULL,

            total_seats INTEGER NOT NULL,

            active INTEGER DEFAULT 1

        )
    """)

    # =========================
    # SEATS TABLE
    # =========================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS seats (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            vehicle_id INTEGER NOT NULL,

            seat_number TEXT NOT NULL,

            seat_type TEXT,

            status TEXT DEFAULT 'AVAILABLE',

            FOREIGN KEY (vehicle_id)
                REFERENCES vehicles(id)

        )
    """)

    connection.commit()

    connection.close()


if __name__ == "__main__":
    create_database()
    print("SmartTravel database created successfully!")