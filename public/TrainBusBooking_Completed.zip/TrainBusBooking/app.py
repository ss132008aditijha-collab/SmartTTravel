import os
import random
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, "smarttravel.db")

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static")
)
app.secret_key = "smarttravel-secret-key-2026"


def get_db_connection():
    connection = sqlite3.connect(DATABASE, timeout=10)
    connection.row_factory = sqlite3.Row

    # Self-healing migration for bookings table columns
    try:
        connection.execute("ALTER TABLE bookings ADD COLUMN vehicle_class TEXT DEFAULT 'STANDARD'")
        connection.commit()
    except sqlite3.OperationalError:
        pass

    try:
        connection.execute("ALTER TABLE bookings ADD COLUMN quota TEXT DEFAULT 'GENERAL'")
        connection.commit()
    except sqlite3.OperationalError:
        pass

    return connection


# ==========================================================
# HOME
# ==========================================================

@app.route("/")
def home():
    return render_template("home.html")


# ==========================================================
# AUTHENTICATION
# ==========================================================

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    message = request.args.get("message")

    if request.method == "POST":
        email = (request.form.get("email") or "").strip()
        password = (request.form.get("password") or "").strip()

        connection = get_db_connection()
        user = connection.execute(
            "SELECT * FROM users WHERE LOWER(email) = LOWER(?) AND password = ?",
            (email, password)
        ).fetchone()
        connection.close()

        if user is None:
            error = "Invalid email or password. Please try again."
            return render_template("login.html", error=error)

        session["user_id"] = user["id"]
        session["user_name"] = user["name"]
        session["user_email"] = user["email"]

        next_page = request.args.get("next") or url_for("home")
        return redirect(next_page)

    return render_template("login.html", error=error, message=message)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


@app.route("/register", methods=["GET", "POST"])
def register():
    error = None

    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        email = (request.form.get("email") or "").strip()
        phone = (request.form.get("phone") or "").strip()
        password = (request.form.get("password") or "").strip()

        if not name or not email or not password:
            error = "Please fill in all required fields."
            return render_template("register.html", error=error)

        connection = get_db_connection()
        try:
            connection.execute(
                """
                INSERT INTO users (name, email, phone, password)
                VALUES (?, ?, ?, ?)
                """,
                (name, email, phone, password)
            )
            connection.commit()
        except sqlite3.IntegrityError:
            connection.close()
            error = "An account with this email address already exists. Please login instead."
            return render_template("register.html", error=error)

        connection.close()
        return redirect(url_for("login", message="Account created successfully! Please log in."))

    return render_template("register.html", error=error)


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    error = None

    if request.method == "POST":
        email = (request.form.get("email") or "").strip()

        connection = get_db_connection()
        user = connection.execute(
            "SELECT * FROM users WHERE LOWER(email) = LOWER(?)",
            (email,)
        ).fetchone()
        connection.close()

        if user is None:
            error = "No account found with this email address. Please check your spelling."
            return render_template("forgot_password.html", error=error)

        return redirect(url_for("reset_password", email=email))

    return render_template("forgot_password.html", error=error)


@app.route("/reset-password", methods=["GET", "POST"])
def reset_password():
    email = request.args.get("email", "")
    error = None

    if request.method == "POST":
        new_password = (request.form.get("password") or "").strip()

        if len(new_password) < 6:
            error = "Password must be at least 6 characters long."
            return render_template("reset_password.html", email=email, error=error)

        connection = get_db_connection()
        connection.execute(
            """
            UPDATE users
            SET password = ?
            WHERE LOWER(email) = LOWER(?)
            """,
            (new_password, email)
        )
        connection.commit()
        connection.close()

        return redirect(url_for("login", message="Password reset successfully! You can now log in."))

    return render_template("reset_password.html", email=email, error=error)


# ==========================================================
# SEARCH RESULTS
# ==========================================================

@app.route("/search")
def search():
    source = (request.args.get("source") or "Bengaluru").strip()
    destination = (request.args.get("destination") or "Chennai").strip()
    journey_date = request.args.get("journey_date") or ""
    transport = (request.args.get("transport") or "train").strip().lower()
    passengers = request.args.get("passengers", "1")
    quota = request.args.get("quota", "GENERAL")

    # Real Indian Railway Trains with distinct AC & Non-AC classes, berth types, and fares
    default_trains = [
        {
            "name": "Karnataka Superfast Express",
            "number": "12627",
            "type": "Superfast Express",
            "departure": "19:20",
            "arrival": "06:00",
            "duration": "10h 40m",
            "rating": "4.7",
            "runs_on": "Mon, Tue, Wed, Thu, Fri, Sat, Sun",
            "pantry": True,
            "amenities": ["Pantry Car", "Charging Point", "E-Catering", "Bedroll"],
            "classes": [
                {"code": "1A", "name": "AC First Class", "price": 2450, "seats": 6, "status": "AVAILABLE 06", "is_ac": True, "desc": "Coupe/Cabin with lockable door & bedding"},
                {"code": "2A", "name": "AC 2 Tier", "price": 1580, "seats": 18, "status": "AVAILABLE 18", "is_ac": True, "desc": "Curtains, reading lights, AC & bedding"},
                {"code": "3A", "name": "AC 3 Tier", "price": 1120, "seats": 38, "status": "AVAILABLE 38", "is_ac": True, "desc": "Air conditioned 3-tier berths with bedroll"},
                {"code": "3E", "name": "AC 3 Economy", "price": 980, "seats": 24, "status": "AVAILABLE 24", "is_ac": True, "desc": "Modern economical 3-tier AC"},
                {"code": "SL", "name": "Sleeper Class (Non-AC)", "price": 460, "seats": 54, "status": "AVAILABLE 54", "is_ac": False, "desc": "Budget non-AC open window sleeper"}
            ]
        },
        {
            "name": "Vande Bharat Express",
            "number": "20608",
            "type": "Semi-High Speed",
            "departure": "05:45",
            "arrival": "10:15",
            "duration": "4h 30m",
            "rating": "4.9",
            "runs_on": "Mon, Tue, Thu, Fri, Sat, Sun",
            "pantry": True,
            "amenities": ["180° Rotating Seats", "Onboard Meals", "Free WiFi", "CCTV Security"],
            "classes": [
                {"code": "EC", "name": "Exec Chair Car (AC)", "price": 1650, "seats": 14, "status": "AVAILABLE 14", "is_ac": True, "desc": "Rotating plush leather seats & hot meals"},
                {"code": "CC", "name": "AC Chair Car", "price": 890, "seats": 52, "status": "AVAILABLE 52", "is_ac": True, "desc": "Air conditioned ergonomic seating with tray table"}
            ]
        },
        {
            "name": "Chennai Mail Express",
            "number": "12608",
            "type": "Mail / Express",
            "departure": "22:30",
            "arrival": "07:00",
            "duration": "8h 30m",
            "rating": "4.5",
            "runs_on": "Daily",
            "pantry": True,
            "amenities": ["Clean Linens", "Reading Lamp", "Pantry Car"],
            "classes": [
                {"code": "2A", "name": "AC 2 Tier", "price": 1520, "seats": 12, "status": "AVAILABLE 12", "is_ac": True, "desc": "Comfortable 2-tier AC with curtains"},
                {"code": "3A", "name": "AC 3 Tier", "price": 1080, "seats": 28, "status": "AVAILABLE 28", "is_ac": True, "desc": "Standard 3-tier AC coach with linens"},
                {"code": "SL", "name": "Sleeper Class (Non-AC)", "price": 420, "seats": 62, "status": "AVAILABLE 62", "is_ac": False, "desc": "Standard non-AC sleeper berths"}
            ]
        },
        {
            "name": "Shatabdi Express",
            "number": "12028",
            "type": "Superfast Shatabdi",
            "departure": "06:00",
            "arrival": "11:00",
            "duration": "5h 00m",
            "rating": "4.8",
            "runs_on": "Daily except Tuesday",
            "pantry": True,
            "amenities": ["Complimentary Snacks", "Newspaper", "Water Bottle", "CCTV"],
            "classes": [
                {"code": "EC", "name": "Exec Chair Car (AC)", "price": 1590, "seats": 16, "status": "AVAILABLE 16", "is_ac": True, "desc": "First class chair car with catering included"},
                {"code": "CC", "name": "AC Chair Car", "price": 850, "seats": 44, "status": "AVAILABLE 44", "is_ac": True, "desc": "Air conditioned comfortable pushback seats"}
            ]
        }
    ]

    # Real Buses with distinct AC vs Non-AC, Sleeper vs Seater options
    default_buses = [
        {
            "name": "IntrCity SmartBus Premium",
            "number": "KA-51-AA-9988",
            "operator": "IntrCity RailYatri",
            "bus_type": "Scania Luxury A/C Sleeper (2+1)",
            "is_ac": True,
            "layout": "sleeper",
            "has_upper_deck": True,
            "departure": "23:00",
            "arrival": "06:45",
            "duration": "7h 45m",
            "rating": "4.9",
            "price": 950,
            "seats": 16,
            "amenities": ["Climate Control AC", "Upper/Lower Deck Berths", "Personal TV", "Sanitized Washroom", "Charging Socket"],
            "badges": ["AC Sleeper", "Top Rated", "Washroom Onboard"]
        },
        {
            "name": "KSRTC Airavat Club Class",
            "number": "KA-01-F-1234",
            "operator": "KSRTC (State Transport)",
            "bus_type": "Volvo Multi-Axle A/C Semi-Sleeper (2+2)",
            "is_ac": True,
            "layout": "seater",
            "has_upper_deck": False,
            "departure": "21:30",
            "arrival": "06:30",
            "duration": "9h 00m",
            "rating": "4.8",
            "price": 850,
            "seats": 24,
            "amenities": ["Multi-Axle Air Suspension", "AC", "Pushback Calf Rest", "Water Bottle", "Blankets"],
            "badges": ["Volvo AC", "Govt Verified", "Punctual"]
        },
        {
            "name": "Zingbus Electric Superfast",
            "number": "KA-04-EV-2026",
            "operator": "Zingbus Electric",
            "bus_type": "Electric A/C Sleeper (2+1)",
            "is_ac": True,
            "layout": "sleeper",
            "has_upper_deck": True,
            "departure": "22:15",
            "arrival": "06:15",
            "duration": "8h 00m",
            "rating": "4.7",
            "price": 880,
            "seats": 18,
            "amenities": ["100% Electric Silent Ride", "AC Sleeper", "Type-C Fast Charging", "Live GPS"],
            "badges": ["EV A/C Sleeper", "Eco Friendly"]
        },
        {
            "name": "Sharma Transports Non-AC Sleeper",
            "number": "KA-02-S-4433",
            "operator": "Sharma Transports",
            "bus_type": "Non-AC Sleeper (2+1)",
            "is_ac": False,
            "layout": "sleeper",
            "has_upper_deck": True,
            "departure": "21:00",
            "arrival": "06:00",
            "duration": "9h 00m",
            "rating": "4.3",
            "price": 580,
            "seats": 22,
            "amenities": ["Sliding Window Berths", "Reading Light", "Individual Fan", "Luggage Bay"],
            "badges": ["Non-AC Sleeper", "Budget Friendly"]
        },
        {
            "name": "KSRTC Rajahamsa Executive",
            "number": "KA-05-CD-5678",
            "operator": "KSRTC",
            "bus_type": "Comfort Pushback Non-AC (2+2)",
            "is_ac": False,
            "layout": "seater",
            "has_upper_deck": False,
            "departure": "20:00",
            "arrival": "05:30",
            "duration": "9h 30m",
            "rating": "4.4",
            "price": 520,
            "seats": 32,
            "amenities": ["Highback Recliner", "Open Ventilation", "Emergency Exit", "First Aid"],
            "badges": ["Non-AC Seater", "Pocket Friendly"]
        }
    ]

    results = default_buses if transport == "bus" else default_trains

    # Test route for no results testing
    if source and source.strip().lower() == "testcity":
        results = []

    return render_template(
        "search_results.html",
        results=results,
        source=source,
        destination=destination,
        journey_date=journey_date,
        transport=transport,
        passengers=passengers,
        quota=quota
    )


# ==========================================================
# BOOKING OVERVIEW
# ==========================================================

@app.route("/booking")
def booking():
    name = request.args.get("name", "Express Journey")
    number = request.args.get("number", "12627")
    price = request.args.get("price", "650")
    transport = request.args.get("transport", "train")
    source = request.args.get("source", "Bengaluru")
    destination = request.args.get("destination", "Chennai")
    journey_date = request.args.get("date") or request.args.get("journey_date", "")
    passengers = request.args.get("passengers", "1")
    vehicle_class = request.args.get("class") or request.args.get("vehicle_class", "3A" if transport == "train" else "AC Sleeper")
    quota = request.args.get("quota", "GENERAL")
    is_ac = request.args.get("is_ac", "1")
    layout = request.args.get("layout", "sleeper")

    return render_template(
        "booking.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        passengers=passengers,
        vehicle_class=vehicle_class,
        quota=quota,
        is_ac=is_ac,
        layout=layout
    )


# ==========================================================
# SEAT SELECTION
# ==========================================================

@app.route("/seat-selection")
def seat_selection():
    name = request.args.get("name", "Express")
    number = request.args.get("number", "12627")
    price = request.args.get("price", "650")
    transport = request.args.get("transport", "train")
    source = request.args.get("source", "Bengaluru")
    destination = request.args.get("destination", "Chennai")
    journey_date = request.args.get("date", "")
    boarding = request.args.get("boarding", "City Main Station")
    passengers = request.args.get("passengers", "1")
    vehicle_class = request.args.get("class") or request.args.get("vehicle_class", "3A" if transport == "train" else "AC Sleeper")
    quota = request.args.get("quota", "GENERAL")
    is_ac = request.args.get("is_ac", "1")
    layout = request.args.get("layout", "sleeper")

    return render_template(
        "seat_selection.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        boarding=boarding,
        passengers=passengers,
        vehicle_class=vehicle_class,
        quota=quota,
        is_ac=is_ac,
        layout=layout
    )


# ==========================================================
# PASSENGER DETAILS
# ==========================================================

@app.route("/passenger-details")
def passenger_details():
    name = request.args.get("name", "")
    number = request.args.get("number", "")
    price = request.args.get("price", "650")
    transport = request.args.get("transport", "train")
    source = request.args.get("source", "")
    destination = request.args.get("destination", "")
    journey_date = request.args.get("date", "")
    boarding = request.args.get("boarding", "")
    seat = request.args.get("seat", "A1")
    passengers = request.args.get("passengers", "1")
    vehicle_class = request.args.get("class") or request.args.get("vehicle_class", "3A" if transport == "train" else "AC Sleeper")
    quota = request.args.get("quota", "GENERAL")
    is_ac = request.args.get("is_ac", "1")

    return render_template(
        "passenger_details.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        boarding=boarding,
        seat=seat,
        passengers=passengers,
        vehicle_class=vehicle_class,
        quota=quota,
        is_ac=is_ac
    )


# ==========================================================
# FOOD SELECTION
# ==========================================================

@app.route("/food")
def food():
    name = request.args.get("name", "")
    number = request.args.get("number", "")
    price = request.args.get("price", "650")
    transport = request.args.get("transport", "train")
    source = request.args.get("source", "")
    destination = request.args.get("destination", "")
    journey_date = request.args.get("date", "")
    boarding = request.args.get("boarding", "")
    seat = request.args.get("seat", "A1")
    vehicle_class = request.args.get("class") or request.args.get("vehicle_class", "3A" if transport == "train" else "AC Sleeper")
    quota = request.args.get("quota", "GENERAL")

    passenger_name = request.args.get("passenger_name", "")
    age = request.args.get("age", "")
    gender = request.args.get("gender", "")
    phone = request.args.get("phone", "")
    email = request.args.get("email", "")

    return render_template(
        "food.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        boarding=boarding,
        seat=seat,
        vehicle_class=vehicle_class,
        quota=quota,
        passenger_name=passenger_name,
        age=age,
        gender=gender,
        phone=phone,
        email=email
    )


# ==========================================================
# PAYMENT CHECKOUT
# ==========================================================

@app.route("/payment")
def payment():
    name = request.args.get("name", "")
    number = request.args.get("number", "")
    price = request.args.get("price", "650")
    transport = request.args.get("transport", "train")
    source = request.args.get("source", "")
    destination = request.args.get("destination", "")
    journey_date = request.args.get("date", "")
    boarding = request.args.get("boarding", "")
    seat = request.args.get("seat", "A1")
    vehicle_class = request.args.get("class") or request.args.get("vehicle_class", "3A" if transport == "train" else "AC Sleeper")
    quota = request.args.get("quota", "GENERAL")

    passenger_name = request.args.get("passenger_name", "")
    age = request.args.get("age", "")
    gender = request.args.get("gender", "")
    phone = request.args.get("phone", "")
    email = request.args.get("email", "")

    food_total = request.args.get("food_total", "0")
    try:
        total = float(price or 0) + float(food_total or 0)
    except ValueError:
        total = float(price or 0)

    return render_template(
        "payment.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        boarding=boarding,
        seat=seat,
        vehicle_class=vehicle_class,
        quota=quota,
        passenger_name=passenger_name,
        age=age,
        gender=gender,
        phone=phone,
        email=email,
        food_total=food_total,
        total=total
    )


# ==========================================================
# COMPLETE BOOKING
# ==========================================================

@app.route("/complete-booking", methods=["POST"])
def complete_booking():
    name = request.form.get("name", "")
    number = request.form.get("number", "")
    price = request.form.get("price", "650")
    transport = request.form.get("transport", "train")
    source = request.form.get("source", "")
    destination = request.form.get("destination", "")
    journey_date = request.form.get("date", "")
    boarding = request.form.get("boarding", "")
    seat = request.form.get("seat", "")
    vehicle_class = request.form.get("vehicle_class", "3A" if transport == "train" else "AC Sleeper")
    quota = request.form.get("quota", "GENERAL")

    passenger_name = request.form.get("passenger_name", "")
    age = request.form.get("age", "")
    gender = request.form.get("gender", "")
    phone = request.form.get("phone", "")
    email = request.form.get("email", "")

    food_total = request.form.get("food_total", "0")
    try:
        ticket_p = float(price or 0)
        food_p = float(food_total or 0)
        total_p = ticket_p + food_p
    except ValueError:
        ticket_p = 650.0
        food_p = 0.0
        total_p = 650.0

    payment_method = request.form.get("payment_method", "DEMO_UPI")

    # Generate a realistic format booking ID
    if transport == "train":
        booking_id = f"IRCTC{random.randint(10000000, 99999999)}"
    else:
        booking_id = f"BUS{random.randint(100000, 999999)}"

    # Save to SQLite database with robust fallback
    try:
        connection = get_db_connection()
        connection.execute(
            """
            INSERT INTO bookings (
                booking_id,
                transport,
                vehicle_name,
                vehicle_number,
                source,
                destination,
                journey_date,
                boarding,
                seat,
                passenger_name,
                age,
                gender,
                phone,
                email,
                ticket_price,
                food_total,
                total,
                payment_method,
                vehicle_class,
                quota,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                booking_id,
                transport,
                name,
                number,
                source,
                destination,
                journey_date,
                boarding,
                seat,
                passenger_name,
                age,
                gender,
                phone,
                email or (session.get("user_email") if "user_email" in session else "guest@smarttravel.com"),
                ticket_p,
                food_p,
                total_p,
                payment_method,
                vehicle_class,
                quota,
                "CONFIRMED"
            )
        )
        connection.commit()
        connection.close()
    except Exception as e:
        print(f"Primary booking insert error: {e}")
        try:
            connection = get_db_connection()
            connection.execute(
                """
                INSERT INTO bookings (
                    booking_id, transport, vehicle_name, vehicle_number,
                    source, destination, journey_date, boarding, seat,
                    passenger_name, age, gender, phone, email,
                    ticket_price, food_total, total, payment_method, status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    booking_id,
                    transport,
                    name,
                    number,
                    source,
                    destination,
                    journey_date,
                    boarding,
                    seat,
                    passenger_name,
                    age,
                    gender,
                    phone,
                    email or (session.get("user_email") if "user_email" in session else "guest@smarttravel.com"),
                    ticket_p,
                    food_p,
                    total_p,
                    payment_method,
                    "CONFIRMED"
                )
            )
            connection.commit()
            connection.close()
        except Exception as e2:
            print(f"Fallback booking insert error: {e2}")

    return redirect(
        url_for(
            "ticket",
            booking_id=booking_id,
            name=name,
            number=number,
            price=ticket_p,
            transport=transport,
            source=source,
            destination=destination,
            date=journey_date,
            boarding=boarding,
            seat=seat,
            passenger_name=passenger_name,
            age=age,
            gender=gender,
            phone=phone,
            email=email,
            food_total=food_p,
            total=total_p,
            payment_method=payment_method,
            vehicle_class=vehicle_class,
            quota=quota
        )
    )


# ==========================================================
# E-TICKET
# ==========================================================

@app.route("/ticket")
def ticket():
    booking_id = request.args.get("booking_id")

    if booking_id:
        connection = get_db_connection()
        booking = connection.execute(
            "SELECT * FROM bookings WHERE booking_id = ?",
            (booking_id,)
        ).fetchone()
        connection.close()

        if booking is not None:
            # Handle potential None for vehicle_class / quota
            try:
                v_class = booking["vehicle_class"] or ("3A" if booking["transport"] == "train" else "AC Sleeper")
            except (IndexError, KeyError):
                v_class = "3A" if booking["transport"] == "train" else "AC Sleeper"

            try:
                v_quota = booking["quota"] or "GENERAL"
            except (IndexError, KeyError):
                v_quota = "GENERAL"

            return render_template(
                "ticket.html",
                name=booking["vehicle_name"],
                number=booking["vehicle_number"],
                price=booking["ticket_price"],
                transport=booking["transport"],
                source=booking["source"],
                destination=booking["destination"],
                journey_date=booking["journey_date"],
                boarding=booking["boarding"],
                seat=booking["seat"],
                passenger_name=booking["passenger_name"],
                age=booking["age"],
                gender=booking["gender"],
                phone=booking["phone"],
                email=booking["email"],
                food_total=booking["food_total"] or 0,
                total=booking["total"],
                payment_method=booking["payment_method"],
                booking_id=booking["booking_id"],
                vehicle_class=v_class,
                quota=v_quota,
                status=booking["status"]
            )

    # Fallback if accessed directly
    name = request.args.get("name", "Express")
    number = request.args.get("number", "12627")
    price = request.args.get("price", "650")
    transport = request.args.get("transport", "train")
    source = request.args.get("source", "Bengaluru")
    destination = request.args.get("destination", "Chennai")
    journey_date = request.args.get("date") or request.args.get("journey_date", "")
    boarding = request.args.get("boarding", "Bengaluru City")
    seat = request.args.get("seat", "B4-24")
    passenger_name = request.args.get("passenger_name", "Valued Passenger")
    age = request.args.get("age", "28")
    gender = request.args.get("gender", "Female")
    phone = request.args.get("phone", "9876543210")
    email = request.args.get("email", "guest@smarttravel.com")
    food_total = request.args.get("food_total", "0")
    total = request.args.get("total", price)
    payment_method = request.args.get("payment_method", "DEMO_UPI")
    vehicle_class = request.args.get("class") or request.args.get("vehicle_class", "3A (AC 3 Tier)" if transport == "train" else "Volvo Multi-Axle AC Sleeper")
    quota = request.args.get("quota", "GENERAL")
    fallback_id = booking_id or (f"IRCTC{random.randint(10000000, 99999999)}" if transport == "train" else f"BUS{random.randint(100000, 999999)}")

    return render_template(
        "ticket.html",
        name=name,
        number=number,
        price=price,
        transport=transport,
        source=source,
        destination=destination,
        journey_date=journey_date,
        boarding=boarding,
        seat=seat,
        passenger_name=passenger_name,
        age=age,
        gender=gender,
        phone=phone,
        email=email,
        food_total=food_total,
        total=total,
        payment_method=payment_method,
        booking_id=fallback_id,
        vehicle_class=vehicle_class,
        quota=quota,
        status="CONFIRMED"
    )


# ==========================================================
# DOWNLOAD OFFICIAL PDF TICKET
# ==========================================================

@app.route("/download-pdf/<booking_id>")
def download_pdf(booking_id):
    from pdf_generator import generate_ticket_pdf
    from flask import Response

    connection = get_db_connection()
    row = connection.execute(
        "SELECT * FROM bookings WHERE booking_id = ?",
        (booking_id,)
    ).fetchone()
    connection.close()

    if row is not None:
        booking_dict = dict(row)
    else:
        booking_dict = {
            "booking_id": booking_id,
            "vehicle_name": request.args.get("name", "Express Journey"),
            "vehicle_number": request.args.get("number", "12627"),
            "ticket_price": request.args.get("price", "650"),
            "transport": request.args.get("transport", "train"),
            "source": request.args.get("source", "Bengaluru"),
            "destination": request.args.get("destination", "Chennai"),
            "journey_date": request.args.get("date", "2026-10-30"),
            "boarding": request.args.get("boarding", "Main Station"),
            "seat": request.args.get("seat", "B4-24"),
            "passenger_name": request.args.get("passenger_name", "Valued Passenger"),
            "age": request.args.get("age", "28"),
            "gender": request.args.get("gender", "Female"),
            "phone": request.args.get("phone", "9876543210"),
            "email": request.args.get("email", "guest@smarttravel.com"),
            "food_total": request.args.get("food_total", "0"),
            "total": request.args.get("total", "650"),
            "payment_method": request.args.get("payment_method", "UPI"),
            "vehicle_class": request.args.get("class") or request.args.get("vehicle_class", "3A (AC 3 Tier)"),
            "quota": request.args.get("quota", "GENERAL"),
            "status": "CONFIRMED"
        }

    pdf_bytes = generate_ticket_pdf(booking_dict)
    return Response(
        pdf_bytes,
        mimetype="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=SmartTravel_Ticket_{booking_id}.pdf",
            "Content-Length": str(len(pdf_bytes)),
            "Cache-Control": "no-cache"
        }
    )


@app.route("/view-pdf/<booking_id>")
def view_pdf(booking_id):
    from pdf_generator import generate_ticket_pdf
    from flask import Response

    connection = get_db_connection()
    row = connection.execute(
        "SELECT * FROM bookings WHERE booking_id = ?",
        (booking_id,)
    ).fetchone()
    connection.close()

    if row is not None:
        booking_dict = dict(row)
    else:
        booking_dict = {
            "booking_id": booking_id,
            "vehicle_name": request.args.get("name", "Express Journey"),
            "vehicle_number": request.args.get("number", "12627"),
            "ticket_price": request.args.get("price", "650"),
            "transport": request.args.get("transport", "train"),
            "source": request.args.get("source", "Bengaluru"),
            "destination": request.args.get("destination", "Chennai"),
            "journey_date": request.args.get("date", "2026-10-30"),
            "boarding": request.args.get("boarding", "Main Station"),
            "seat": request.args.get("seat", "B4-24"),
            "passenger_name": request.args.get("passenger_name", "Valued Passenger"),
            "age": request.args.get("age", "28"),
            "gender": request.args.get("gender", "Female"),
            "phone": request.args.get("phone", "9876543210"),
            "email": request.args.get("email", "guest@smarttravel.com"),
            "food_total": request.args.get("food_total", "0"),
            "total": request.args.get("total", "650"),
            "payment_method": request.args.get("payment_method", "UPI"),
            "vehicle_class": request.args.get("class") or request.args.get("vehicle_class", "3A (AC 3 Tier)"),
            "quota": request.args.get("quota", "GENERAL"),
            "status": "CONFIRMED"
        }

    pdf_bytes = generate_ticket_pdf(booking_dict)
    return Response(
        pdf_bytes,
        mimetype="application/pdf",
        headers={
            "Content-Disposition": f"inline; filename=SmartTravel_Ticket_{booking_id}.pdf",
            "Content-Length": str(len(pdf_bytes)),
            "Cache-Control": "no-cache"
        }
    )


# ==========================================================
# MY BOOKINGS
# ==========================================================

@app.route("/bookings")
def bookings():
    connection = get_db_connection()

    if "user_email" in session:
        user_bookings = connection.execute(
            """
            SELECT * FROM bookings
            WHERE LOWER(email) = LOWER(?)
            ORDER BY id DESC
            """,
            (session["user_email"],)
        ).fetchall()
    else:
        user_bookings = connection.execute(
            """
            SELECT * FROM bookings
            ORDER BY id DESC
            """
        ).fetchall()

    connection.close()

    return render_template(
        "bookings.html",
        bookings=user_bookings
    )


# ==========================================================
# CANCEL BOOKING
# ==========================================================

@app.route("/cancel-booking/<booking_id>", methods=["POST", "GET"])
def cancel_booking(booking_id):
    connection = get_db_connection()
    connection.execute(
        """
        UPDATE bookings
        SET status = 'CANCELLED'
        WHERE booking_id = ?
        """,
        (booking_id,)
    )
    connection.commit()
    connection.close()

    return redirect(url_for("bookings", message=f"Booking {booking_id} has been cancelled."))


# ==========================================================
# DOWNLOAD WORKING PROJECT CODE ZIP
# ==========================================================

@app.route("/download-project-zip")
@app.route("/download-zip")
@app.route("/TrainBusBooking_Complete_Working.zip")
@app.route("/SmartTravel_Completed.zip")
def download_project_zip():
    from flask import send_file

    zip_candidates = [
        os.path.join(BASE_DIR, "static", "TrainBusBooking_Complete_Working.zip"),
        os.path.join(BASE_DIR, "static", "SmartTravel_Completed.zip"),
        os.path.join(os.path.dirname(BASE_DIR), "public", "TrainBusBooking_Complete_Working.zip"),
    ]
    for z in zip_candidates:
        if os.path.exists(z):
            return send_file(
                z,
                mimetype="application/zip",
                as_attachment=True,
                download_name="TrainBusBooking_Complete_Working.zip"
            )

    # In-memory dynamic ZIP generator fallback
    import io
    import zipfile
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(BASE_DIR):
            if "venv" in root or "__pycache__" in root:
                continue
            for file in files:
                if file.endswith(".pyc") or file.endswith(".zip"):
                    continue
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, start=os.path.dirname(BASE_DIR))
                zf.write(full_path, rel_path)
    zip_buffer.seek(0)
    return send_file(
        zip_buffer,
        mimetype="application/zip",
        as_attachment=True,
        download_name="TrainBusBooking_Complete_Working.zip"
    )


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)