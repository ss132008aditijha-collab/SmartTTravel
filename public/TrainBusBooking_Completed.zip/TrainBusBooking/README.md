# SmartTravel - Complete Train & Bus Ticket Booking System

A fully-featured, production-ready web application built with **Python (Flask)** and **SQLite**, with zero external cloud dependencies.

---

## 🚀 Key Features

1. **Indian Railways (Train Booking Experience)**:
   - Real Railway Classes: **1A** (AC First Class), **2A** (AC 2-Tier), **3A** (AC 3-Tier), **3E** (AC 3 Economy), **SL** (Sleeper Class Non-AC), **CC / EC** (AC Chair Car / Executive).
   - Real Quotas: **General (GN)**, **Tatkal (TQ)**, **Ladies (LD)**, **Senior Citizen (SS)**.
   - Dynamic Coach & Berth Layouts matching the selected class (Lower Berth, Middle Berth, Upper Berth, Side Lower, Side Upper).
   - Berth preference and Government Photo ID verification.

2. **Intercity Bus Booking Experience**:
   - Distinct categories: **AC Sleeper (2+1)**, **Volvo Multi-Axle AC (2+2)**, **Electric AC (EV)**, **Non-AC Sleeper**, **Non-AC Seater**.
   - Interactive Deck Switcher for Sleeper buses: **[Lower Deck]** vs. **[Upper Deck]** with single window sleeper bunks and double berths.
   - Pick-up points with landmarks and reporting times.

3. **Official E-Ticket & Native Vector PDF Generator**:
   - Zero-dependency built-in pure Python vector PDF generator (`pdf_generator.py`).
   - One-click **"Download Official PDF Ticket"** downloads a genuine, fully formatted PDF (`SmartTravel_Ticket_<PNR>.pdf`).
   - Inline PDF viewer tab (`/view-pdf/<booking_id>`).
   - Sandboxed iframe-unblocked printing with QR code boarding pass.

4. **Complete Booking Lifecycle**:
   - Dynamic Search & Filter by AC / Non-AC, departure times, prices, and classes.
   - Live seat locking and fare calculation.
   - Passenger details and pre-ordered meals / IRCTC e-catering.
   - Checkout with simulated UPI, Card, Net Banking, and Viva/Demo payment.
   - "My Bookings" history and ticket cancellation.
   - User authentication (Register, Login, Password Reset).

---

## 💻 How to Run Locally

### Option 1: Automatic Setup (Recommended)
Double-click `start.bat` (Windows) or run `./start.sh` (Mac/Linux).

### Option 2: Manual Terminal Setup
1. **Open a terminal** inside the `TrainBusBooking` directory:
   ```bash
   cd TrainBusBooking
   ```

2. **Install requirements**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Initialize database** (seeded with vehicles and routes):
   ```bash
   python database.py
   ```

4. **Start the application**:
   ```bash
   python app.py
   ```

5. **Open your browser**:
   Navigate to: **`http://localhost:5000`**

---

## 📁 Project Directory Structure
```
TrainBusBooking/
│── app.py                   # Main Flask application & routes
│── database.py              # SQLite schema, tables, seed data
│── pdf_generator.py         # Pure-Python vector PDF generator
│── smarttravel.db           # Pre-seeded SQLite database
│── requirements.txt         # Python package dependencies
│── README.md                # Documentation & instructions
│── start.bat                # 1-click Windows launcher
│── start.sh                 # 1-click Linux/Mac launcher
│── templates/               # 13 Jinja2 HTML templates
│   ├── home.html            # Landing page with search bar
│   ├── search_results.html  # Search results with AC filters
│   ├── booking.html         # Boarding & class selection
│   ├── seat_selection.html  # Interactive coach / deck layout
│   ├── passenger_details.html
│   ├── food.html            # Meal selection
│   ├── payment.html         # Multi-method checkout
│   ├── ticket.html          # Confirmed E-ticket & PDF export
│   ├── bookings.html        # My bookings dashboard
│   ├── login.html
│   ├── register.html
│   ├── forgot_password.html
│   └── reset_password.html
└── static/
    ├── style.css            # Responsive master stylesheet
    ├── js/                  # Client-side scripts
    │   ├── ticket.js        # PDF download & print logic
    │   ├── seat-selection.js# Seat toggle & price calculator
    │   ├── filters.js       # Live search filters
    │   ├── main.js
    │   ├── passenger.js
    │   ├── payment.js
    │   └── html2pdf.bundle.min.js
    └── images/              # Assets & brand graphics
```
