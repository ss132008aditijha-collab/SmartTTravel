#!/usr/bin/env bash
echo "========================================================"
echo " Starting SmartTravel Booking System..."
echo "========================================================"
echo ""

if ! command -v python3 &> /dev/null; then
    echo "[ERROR] python3 could not be found. Please install Python 3.8+."
    exit 1
fi

echo "[1/3] Installing dependencies..."
python3 -m pip install -r requirements.txt

echo ""
echo "[2/3] Setting up SQLite database..."
python3 database.py

echo ""
echo "[3/3] Launching Flask server on http://localhost:5000 ..."
echo "Press Ctrl+C to stop the server at any time."
echo ""
python3 app.py
