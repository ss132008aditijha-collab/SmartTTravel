@echo off
title SmartTravel - Train & Bus Ticket Booking System
echo ========================================================
echo  Starting SmartTravel Booking System...
echo ========================================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not added to your PATH.
    echo Please install Python 3.8+ from https://www.python.org/
    pause
    exit /b
)

echo [1/3] Installing dependencies...
pip install -r requirements.txt

echo.
echo [2/3] Setting up SQLite database...
python database.py

echo.
echo [3/3] Launching Flask server on http://localhost:5000 ...
echo Press Ctrl+C to stop the server at any time.
echo.
python app.py
pause
