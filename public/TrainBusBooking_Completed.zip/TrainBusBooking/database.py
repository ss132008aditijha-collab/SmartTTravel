import sqlite3

DATABASE = "smarttravel.db"


def get_db_connection():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection


def create_database():

    connection = get_db_connection()

    cursor = connection.cursor()

    # =========================
    # USERS TABLE
    # =========================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            name TEXT NOT NULL,

            email TEXT UNIQUE NOT NULL,

            phone TEXT NOT NULL,

            password TEXT NOT NULL

        )
    """)

    # =========================
    # BOOKINGS TABLE
    # =========================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS bookings (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            booking_id TEXT UNIQUE,

            transport TEXT,

            vehicle_name TEXT,

            vehicle_number TEXT,

            source TEXT,

            destination TEXT,

            journey_date TEXT,

            boarding TEXT,

            seat TEXT,

            passenger_name TEXT,

            age INTEGER,

            gender TEXT,

            phone TEXT,

            email TEXT,

            ticket_price REAL,

            food_total REAL,

            total REAL,

            payment_method TEXT,

            vehicle_class TEXT DEFAULT 'STANDARD',

            quota TEXT DEFAULT 'GENERAL',

            status TEXT DEFAULT 'CONFIRMED'

        )
    """)

    # Ensure new columns exist for existing databases
    try:
        cursor.execute("ALTER TABLE bookings ADD COLUMN vehicle_class TEXT DEFAULT 'STANDARD'")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE bookings ADD COLUMN quota TEXT DEFAULT 'GENERAL'")
    except sqlite3.OperationalError:
        pass

    # =========================
    # VEHICLES TABLE
    # =========================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS vehicles (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            transport TEXT NOT NULL,

            name TEXT NOT NULL,

            number TEXT UNIQUE NOT NULL,

            source TEXT NOT NULL,

            destination TEXT NOT NULL,

            departure TEXT NOT NULL,

            arrival TEXT NOT NULL,

            duration TEXT NOT NULL,

            price REAL NOT NULL,

            total_seats INTEGER NOT NULL,

            active INTEGER DEFAULT 1

        )
    """)

    # =========================
    # SEATS TABLE
    # =========================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS seats (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            vehicle_id INTEGER NOT NULL,

            seat_number TEXT NOT NULL,

            seat_type TEXT,

            status TEXT DEFAULT 'AVAILABLE',

            FOREIGN KEY (vehicle_id)
                REFERENCES vehicles(id)

        )
    """)

    # =========================
    # SEED VEHICLES IF EMPTY
    # =========================
    cursor.execute("SELECT COUNT(*) FROM vehicles")
    if cursor.fetchone()[0] == 0:
        sample_vehicles = [
            ("train", "Vande Bharat Express", "20608", "Bengaluru", "Chennai", "05:45", "10:15", "4h 30m", 980.0, 52, 1),
            ("train", "Karnataka Express", "12627", "Bengaluru", "Chennai", "19:20", "06:00", "10h 40m", 650.0, 24, 1),
            ("train", "Chennai Express", "12608", "Bengaluru", "Chennai", "22:30", "07:00", "8h 30m", 720.0, 18, 1),
            ("train", "Shatabdi Express", "12028", "Bengaluru", "Chennai", "06:00", "11:00", "5h 00m", 890.0, 36, 1),
            ("train", "Rajdhani Superfast", "22691", "Bengaluru", "Delhi", "20:00", "05:30", "33h 30m", 2450.0, 15, 1),
            ("train", "Deccan Queen", "12124", "Pune", "Mumbai", "07:15", "10:25", "3h 10m", 450.0, 42, 1),
            ("train", "Pink City Superfast", "12986", "Delhi", "Jaipur", "06:05", "10:35", "4h 30m", 560.0, 28, 1),
            ("bus", "KSRTC Airavat Club Class (Multi-Axle)", "KA-01-F-1234", "Bengaluru", "Chennai", "21:30", "06:30", "9h 00m", 850.0, 30, 1),
            ("bus", "KSRTC Rajahamsa Executive", "KA-05-CD-5678", "Bengaluru", "Chennai", "20:00", "05:30", "9h 30m", 700.0, 20, 1),
            ("bus", "IntrCity SmartBus Premium A/C Sleeper", "KA-51-AA-9988", "Bengaluru", "Chennai", "23:00", "06:45", "7h 45m", 950.0, 14, 1),
            ("bus", "SRS Travels Volvo A/C Multi-Axle", "KA-04-B-4321", "Bengaluru", "Hyderabad", "21:00", "06:30", "9h 30m", 920.0, 22, 1),
            ("bus", "Zingbus Electric Superfast", "DL-01-EE-7766", "Delhi", "Jaipur", "07:00", "12:15", "5h 15m", 599.0, 19, 1),
            ("bus", "VRL Travels I-Shift Multi-Axle", "MH-12-Q-5544", "Mumbai", "Pune", "06:30", "10:15", "3h 45m", 480.0, 35, 1)
        ]
        cursor.executemany("""
            INSERT INTO vehicles (transport, name, number, source, destination, departure, arrival, duration, price, total_seats, active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, sample_vehicles)

    connection.commit()
    connection.close()


if __name__ == "__main__":
    create_database()
    print("SmartTravel database created and seeded successfully!")